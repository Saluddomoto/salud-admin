<?php
/**
 * Salud テーマ functions
 *
 * - スタイル読み込み
 * - テーマサポート
 * - カスタム投稿タイプ（実績・セミナー・お客様の声・補助金制度・お知らせ・サービス）
 * - AIO/SEO 用 構造化データ（JSON-LD）
 *
 * @package Salud
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SALUD_VERSION', '1.1.0' );

// カスタマイザー（外観 > カスタマイズ で主要テキストを編集）
require_once get_theme_file_path( 'inc/customizer.php' );

/**
 * テーマオプションの簡易取得ヘルパー。
 * 将来カスタマイザー/ACF に置き換えやすいよう1箇所に集約。
 */
function salud_opt( $key, $default = '' ) {
	$map = array(
		'line_url'    => 'https://line.me/R/ti/p/@388rsdlz',      // 公式LINE「補助金の窓口」
		'diag_url'    => 'https://hojokin-app.vercel.app/',        // 補助金診断ツール
		'tel'         => '050-6869-6588',
		'address'     => '東京都渋谷区道玄坂1丁目10番8号',
		'support_id'  => '109713007312',                          // 経営革新等支援機関 認定ID
	);
	$val = get_theme_mod( 'salud_' . $key, isset( $map[ $key ] ) ? $map[ $key ] : $default );
	return $val ? $val : $default;
}

/**
 * テーマサポート
 */
function salud_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'automatic-feed-links' );
	register_nav_menus( array(
		'primary' => 'グローバルナビ',
		'footer'  => 'フッターナビ',
	) );
}
add_action( 'after_setup_theme', 'salud_setup' );

/**
 * スタイル読み込み
 */
function salud_assets() {
	wp_enqueue_style( 'salud-style', get_stylesheet_uri(), array(), SALUD_VERSION );
}
add_action( 'wp_enqueue_scripts', 'salud_assets' );

/**
 * 不要な WP 既定出力を抑制（軽量化・Core Web Vitals 対策）
 */
function salud_cleanup() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
}
add_action( 'init', 'salud_cleanup' );

/**
 * 検索エンジン非公開（noindex）。
 * ★ユーザー確認後に本公開する。公開OKになったら SALUD_NOINDEX を false にするか、
 *   この関数を削除して「設定 > 表示設定 > 検索エンジンでの表示」を調整する。
 */
if ( ! defined( 'SALUD_NOINDEX' ) ) {
	define( 'SALUD_NOINDEX', true );
}
function salud_noindex() {
	if ( SALUD_NOINDEX ) {
		echo '<meta name="robots" content="noindex, nofollow, noarchive">' . "\n";
	}
}
add_action( 'wp_head', 'salud_noindex', 1 );

/**
 * カスタム投稿タイプ（DESIGN: 01-sitemap.md に準拠）
 */
function salud_cpts() {
	$defs = array(
		'works'   => array( '導入事例', 'dashicons-portfolio' ),
		'seminar' => array( 'セミナー', 'dashicons-megaphone' ),
		'voice'   => array( 'お客様の声', 'dashicons-format-quote' ),
		'hojokin' => array( '補助金制度', 'dashicons-money-alt' ),
		'service' => array( 'サービス', 'dashicons-screenoptions' ),
		'news'    => array( 'お知らせ', 'dashicons-admin-post' ),
	);
	foreach ( $defs as $slug => $d ) {
		register_post_type( $slug, array(
			'label'        => $d[0],
			'public'       => true,
			'has_archive'  => true,
			'menu_icon'    => $d[1],
			'show_in_rest' => true,
			'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
			'rewrite'      => array( 'slug' => $slug ),
		) );
	}
}
add_action( 'init', 'salud_cpts' );

/**
 * ============ AIO / SEO 構造化データ（JSON-LD） ============
 * ChatGPT・Google AI Overviews 等に引用されやすくするため、
 * 会社情報・サービス・料金・FAQ を機械可読で出力する。
 * 詳細方針: docs/web-renewal/07-aio-seo.md
 */
function salud_jsonld() {
	// 検索非公開の間は構造化データも出さない（確認後に本公開でまとめて有効化）
	if ( SALUD_NOINDEX ) {
		return;
	}
	$org = array(
		'@context'    => 'https://schema.org',
		'@type'       => array( 'Organization', 'ProfessionalService' ),
		'name'        => '株式会社Salud',
		'alternateName' => '補助金の窓口',
		'url'         => home_url( '/' ),
		'telephone'   => salud_opt( 'tel' ),
		'address'     => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => '道玄坂1-10-8',
			'addressLocality' => '渋谷区',
			'addressRegion'   => '東京都',
			'addressCountry'  => 'JP',
		),
		'description' => '中小企業庁認定の経営革新等支援機関。補助金・融資による資金調達から、Web制作・AI開発による実装まで一貫して支援するワンストップの戦略実行支援会社。',
		'knowsAbout'  => array( '補助金申請', 'ものづくり補助金', '持続化補助金', 'IT導入補助金', '省力化投資補助金', '融資支援', 'Web制作', 'AI開発' ),
		'areaServed'  => array( '@type' => 'Country', 'name' => '日本' ),
		'makesOffer'  => array(
			array( '@type' => 'Offer', 'itemOffered' => array( '@type' => 'Service', 'name' => '補助金申請支援' ), 'priceSpecification' => array( '@type' => 'PriceSpecification', 'description' => '基本料金10万〜15万円（税別）+ 成功報酬 採択額の10〜15%' ) ),
			array( '@type' => 'Offer', 'itemOffered' => array( '@type' => 'Service', 'name' => '融資支援' ) ),
			array( '@type' => 'Offer', 'itemOffered' => array( '@type' => 'Service', 'name' => 'Web制作・LP制作' ) ),
			array( '@type' => 'Offer', 'itemOffered' => array( '@type' => 'Service', 'name' => 'AI活用・業務効率化' ) ),
		),
	);

	echo "\n" . '<script type="application/ld+json">' . wp_json_encode( $org, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";

	// フロントページには FAQ スキーマも出す（AIの回答に最も引用されやすい）
	if ( is_front_page() ) {
		$faq = array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => array(
				salud_faq( 'ものづくり補助金はいくらもらえますか？', 'ものづくり補助金は、設備投資やシステム構築を対象に最大4,000万円（補助率1/2〜2/3）が交付される制度です。' ),
				salud_faq( '補助金の申請にはいくらかかりますか？', '相談・初回診断は無料です。ご依頼時の基本料金は10万〜15万円（税別）、採択された場合のみ成功報酬として採択額の10〜15%を頂きます。不採択なら成功報酬はかかりません。' ),
				salud_faq( '全国対応していますか？', 'はい、全国対応しています。オンライン（Zoom・LINE）を基本に、必要に応じて訪問も行います。' ),
				salud_faq( '補助金以外の支援もありますか？', '融資による資金調達、Web制作・LP制作、AI活用・業務効率化まで、ひとつの窓口で戦略から実行まで支援します。' ),
			),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $faq, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
	}
}
add_action( 'wp_head', 'salud_jsonld', 20 );

function salud_faq( $q, $a ) {
	return array(
		'@type'          => 'Question',
		'name'           => $q,
		'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $a ),
	);
}

/**
 * メタディスクリプション + OGP / Twitter カード（SEO・SNS共有UX・CV向上）
 * OGP は検索非公開中でも LINE / SNS の共有プレビューで使うため常時出力。
 */
function salud_meta_ogp() {
	$default_desc = '補助金・融資による資金調達から、Web制作・AI開発の実装まで。中小企業庁認定の経営革新等支援機関がワンストップで戦略から実行まで伴走します。相談・診断は無料、成功報酬型。';
	if ( is_front_page() ) {
		$title = get_bloginfo( 'name' ) . '｜補助金・融資・Web・AIのワンストップ支援';
		$desc  = $default_desc;
		$url   = home_url( '/' );
	} elseif ( is_singular() ) {
		$title = get_the_title() . '｜' . get_bloginfo( 'name' );
		$desc  = has_excerpt() ? get_the_excerpt() : $default_desc;
		$url   = get_permalink();
	} else {
		$title = wp_get_document_title();
		$desc  = $default_desc;
		$url   = home_url( add_query_arg( array() ) );
	}
	$desc = mb_substr( wp_strip_all_tags( $desc ), 0, 120 );
	$img  = get_theme_mod( 'salud_ogp_image', '' );

	echo "\n" . '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	if ( $img ) {
		echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
}
add_action( 'wp_head', 'salud_meta_ogp', 5 );
